# FloodAI – Real Full-Stack AI Disaster Response

This is a real frontend + Node/Express backend + MongoDB + Gemini AI + Socket.IO application. It is NOT a static HTML demo.

## 1. Requirements
- Node.js 18+
- MongoDB Community running locally OR a MongoDB Atlas connection string
- Gemini API key

## 2. Setup
Open a terminal in `backend`:

```bash
npm install
copy .env.example .env
```

Edit `.env` and set `MONGODB_URI`, `JWT_SECRET`, and `GEMINI_API_KEY`.

Then:
```bash
npm run dev
```

Open **http://localhost:5000**. Do NOT double-click `frontend/index.html`.

## 3. Admin login
Default values in `.env`:
- Email: `admin@floodai.local`
- Password: `Admin@12345`

Change them before real deployment.

## 4. What is connected
Frontend → REST API → Express backend → MongoDB.
Emergency reports → Gemini AI → AI result saved in MongoDB.
Socket.IO pushes new/updated cases to the dashboard in real time.

## 5. MongoDB collections
`users`, `emergencies`, `missingpersons`, `volunteers`.

## 6. Important
If `GEMINI_API_KEY` is missing, the app will NOT fake an AI result; the report will return an error telling you to configure the key.
